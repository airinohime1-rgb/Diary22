# Baby Tomato's Diary — GitHub Pages ready

This package is arranged for GitHub Pages: **`index.html` is at the ZIP root**.
Do not upload the ZIP itself as the website. Extract it, then upload the files inside it.

## Publish it

1. Open your GitHub repository.
2. Choose **Add file → Upload files**.
3. Extract this ZIP on your device and upload **all files inside the extracted folder**.
   The repository's top level must show `index.html`, `manifest.webmanifest`,
   `sw.js`, `tomato-icon.svg`, and `.nojekyll` together.
4. Commit the upload to the branch you want to publish (commonly `main`).
5. Open **Settings → Pages**.
6. Under **Build and deployment**, choose **Deploy from a branch**.
7. Select branch `main` and folder `/(root)`, then Save.
8. Wait for the Pages deployment to finish. Open the exact URL shown in
   **Settings → Pages**. For a project repository it normally looks like
   `https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/`.

## Important

- Do not put these files inside an extra `BabyTomatoDiary.../` folder in the repository.
- Do not use the repository's source-code ZIP download as the published website.
- If you already had a Pages deployment, check that Pages is publishing the same
  branch and folder where `index.html` is located.
- If the repository is named `YOUR-USERNAME.github.io`, its site URL is
  `https://YOUR-USERNAME.github.io/` (no repository suffix).
- After replacing files, wait for the Pages deployment to complete and refresh the
  published URL. The service-worker cache version has been updated.
